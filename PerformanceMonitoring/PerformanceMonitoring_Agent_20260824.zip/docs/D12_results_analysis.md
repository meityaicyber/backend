# D12: Results Analysis

## Agency Performance Distribution
The synthetic dataset generates 10,000 agencies. Following the continuous scoring formula (where scores are normalized 0-100 and weighted), the median performance score typically ranges around 84.
- Agencies exceeding the ~82.5 threshold are highly likely to be predicted as "renewed".
- Due to the added 5% noise in the label generation, about 5% of agencies receive a decision contrary to their pure latent score, reflecting unobservable variance (e.g., policy constraints, budget, manual overrides).

## Impact of Data Missingness
- Agencies missing 1 or 2 features (up to the limit) trigger a proportional weight redistribution. Their scores are mathematically comparable but carry a higher inherent variance.
- Agencies missing >2 features are explicitly marked as "not_assessable", assigned a score of 0, and rank is suppressed (null). This ensures no agency is silently approved or ranked highly when data is insufficient.
- Missing values in `past_renewal_status` represent sparse history and are heavily penalized if treated as 0, or dynamically accommodated if marked missing.

## Determinism
Using seeded Random (seed=42 for standard runs), the distribution remains perfectly stable across repeated execution on the same machine.
