# D13: Comparative Study

## Classification Model Selection

During Phase 3 experiments, four models were evaluated for predicting renewal classification based on historical performance:
1. **Baseline (Most Frequent)**: Macro-F1 = 0.406
2. **Gradient Boosting**: Macro-F1 = 0.872
3. **SVM (Calibrated)**: Macro-F1 = 0.890
4. **Neural Network (MLP)**: Macro-F1 = 0.922

### Why Gradient Boosting Was Selected
While the Neural Network achieved the highest F1 score (0.922) and SVM was highly competitive, Gradient Boosting was selected for the final production pipeline. 
**Justification**:
1. **Interpretability**: As a government auditing agency module, regulatory compliance requires explaining adverse decisions. Gradient Boosting provides native feature importance metrics, allowing the agency to understand exactly which features contributed to a low renewal probability. SVM and Neural Networks are black-boxes by comparison.
2. **Robustness to Scaling**: Tree-based models handle unscaled and disparate data (e.g. days vs percentages vs team size) natively without strict normalization requirements.
3. **Offline Stability**: Training and inference are highly stable and computationally inexpensive in an air-gapped, standard CPU environment compared to MLP.

## Missing Data & Scaling Strategy
- **Median Imputation** was chosen over Mean or Constant (-1) imputation as it proved more robust to the explicitly injected outliers (e.g. efficiency=1000 days).
- **RobustScaler** was tested but deemed unnecessary for Gradient Boosting, though it improved SVM performance significantly over MinMaxScaler.

## Final Review
The pipeline strictly enforces independent configuration. The scoring calculation remains purely mathematical and deterministic, distinct from the probabilistic model prediction, ensuring rank integrity regardless of AI predictions.
