# D1 Feature Definition Document

This document defines the six mandatory features, the mathematical derivation of scoring, and missing-data behavior.

## 1. Audit Timeliness
- **Operational Definition**: Proportion of audit reports delivered on schedule.
- **Computation**: `(Reports delivered on time / Total reports) * 100`
- **Unit**: Percentage
- **Permitted Range**: [0, 100]
- **Direction**: Higher is better
- **Missing-Data Rule**: "not assessable". Re-normalize remaining weights for continuous score.
- **Malformed/Outlier Rule**: Strictly enforce range [0, 100]. Values outside are "not assessable".
- **Justification**: Percentage is standard and directly interpretable for timeliness.

## 2. Audit Efficiency
- **Operational Definition**: Average duration taken to complete an audit.
- **Computation**: Total days taken for all audits / Number of audits
- **Unit**: Days
- **Permitted Range**: [1, 365]
- **Direction**: Lower is better
- **Missing-Data Rule**: "not assessable"
- **Malformed/Outlier Rule**: Values <= 0 or > 365 are "not assessable".
- **Justification**: Measured in days as it is standard in project management. A cap of 365 days filters out severely stalled audits.

## 3. Error Rate
- **Operational Definition**: Number of discrepancies identified in audit reports.
- **Computation**: Total discrepancies / Number of reports
- **Unit**: Errors per report
- **Permitted Range**: [0, 50]
- **Direction**: Lower is better
- **Missing-Data Rule**: "not assessable"
- **Malformed/Outlier Rule**: Values > 50 are "not assessable".
- **Justification**: Direct count is easily measurable. >50 discrepancies is treated as functionally broken data.

## 4. Agency Scale (Composite)
- **Operational Definition**: Scale based on team size and operational experience.
- **Raw Inputs**: `team_size` (people, [1, 1000]), `years_experience` (years, [0, 100])
- **Computation**: `0.5 * min((team_size/100)*100, 100) + 0.5 * min((years_experience/20)*100, 100)`
- **Unit**: Scale index
- **Permitted Range**: [0, 100]
- **Direction**: Higher is better
- **Missing-Data Rule**: If any component missing -> "not assessable"
- **Malformed/Outlier Rule**: Clamp components to max bounds before applying formula.
- **Justification**: Equally weights team capacity and longevity. Maxes out at 100 people and 20 years.

## 5. Compliance Adherence
- **Operational Definition**: Level of adherence to established auditing standards.
- **Computation**: Evaluated compliance score
- **Unit**: Percentage
- **Permitted Range**: [0, 100]
- **Direction**: Higher is better
- **Missing-Data Rule**: "not assessable"
- **Malformed/Outlier Rule**: Strictly enforce range [0, 100].
- **Justification**: Direct percentage metric of met standards.

## 6. Past Renewal Status
- **Operational Definition**: Historical record of empanelment renewals and revocations.
- **Computation**: `renewals / (renewals + revocations)`
- **Unit**: Ratio
- **Permitted Range**: [0, 1]
- **Direction**: Higher is better
- **Sparse History Rule**: If history < 2 decisions, mark as "not assessable".
- **Missing-Data Rule**: "not assessable"
- **Justification**: Ratio represents historical success. Too few decisions (<2) makes the ratio statistically unreliable.

## Continuous Performance Scoring Architecture
The scoring system is *independent* of the renewal classification prediction. 
It maps all 6 features to a [0, 100] scale, applies weighting from `scoring_config.json`, and outputs a continuous score.

If features are "not assessable", their weights are proportionally redistributed to the valid features. If more than 2 features are missing, the agency's total score is "not assessable".

Ties are resolved deterministically by favoring higher compliance adherence, then timeliness.

## Decision Boundary Semantics
Models predict a renewal probability. Threshold is configured at `0.50`. Epsilon is `0.05`. Probabilities between `0.45` and `0.55` are flagged as `close_to_decision_boundary`.
