# D11: Runbook

## Setup (Offline-Friendly)
1. Ensure Python 3.14+ is installed.
2. Execute the offline installer:
   ```bash
   deploy/install_offline.bat
   ```
3. Run the installation verification and smoke tests:
   ```bash
   python deploy/verify_install.py
   ```

## End-to-End Execution
To run the entire pipeline automatically (Dataset Generation, Model Training, Model Evaluation, and Performance Scoring):
```bash
python -m src.run_pipeline
```
Outputs will be stored in `/output`.

## Generating Datasets
```bash
python -m src.dataset_generator --config config/generator_config.json -n 10000 --output data/sample_dataset.json
```

## Running Components Manually
**Training**:
```bash
python -m src.pipeline.train --config-prep config/preprocessing_config.json --config-model config/model_config.json --dataset data/sample_dataset.json --output output/models
```

**Evaluation**:
```bash
python -m src.pipeline.evaluate --config-prep config/preprocessing_config.json --dataset data/sample_dataset.json --models output/models --output output/evaluation
```

**Scoring**:
```bash
python -m src.pipeline.score --config-scoring config/scoring_config.json --config-schema config/feature_schema.json --models-meta output/models/models_metadata.json --dataset data/sample_dataset.json --output output/scoring
```

## Configuration Versioning
To bump a configuration version with a tracked history:
```bash
python -m src.versioning.cli create --change "Description" --approver "User" --component "scoring_config" --file config/scoring_config.json --new-version "1.1.0"
```
