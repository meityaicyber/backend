# D10: Design and Derivation Document

## Synthetic Label Mechanism
The renewal outcome is synthetically generated to simulate real-world auditing decisions. It uses a linear combination of the six core features, weighted according to their relative importance. This "latent score" represents the true underlying quality of the agency.
- `latent_score = \sum (weight_i * normalized_feature_i)`

The weights used are: Timeliness (0.25), Efficiency (0.20), Error Rate (0.20), Scale (0.05), Compliance (0.20), Past Renewal (0.10).

## Thresholds
Through empirical calculation, the median latent score of a standard 10,000 agency population is ~0.84. To simulate a realistic environment where ~70% of agencies are renewed, the `latent_score_threshold` is set at `0.825`, aligning precisely with the 30th percentile. 
Agencies with a latent score >= 0.825 are assigned `renewal = 1` (Renewed). A `5%` random label flipping noise is added to simulate unobservable external factors (e.g., political or budget constraints).

## Parameter Tuning
During hyperparameter optimization (Phase 4), `GridSearchCV` is used to tune the parameters:
- **Gradient Boosting**: Tuned `n_estimators` (50, 100) and `max_depth` (3, 5).
- **SVM**: Tuned `C` (0.1, 1.0) with Platt Scaling (CalibratedClassifierCV).
- **Neural Network**: Tuned hidden layer structures (16-8 vs 32-16).
These are executed dynamically; no fixed static parameters are hardcoded in the scripts.
